<!-- Banner Ads  -->
<section id="banner_adds">
    <div class="container py-5 text-center">
        <img src="./assets/banner1-cr-500x150.jpg" alt="banner1" class="img-fluid">
        <img src="./assets/banner2-cr-500x150.jpg" alt="banner1" class="img-fluid">
    </div>
</section>
<!-- !Banner Ads  -->
